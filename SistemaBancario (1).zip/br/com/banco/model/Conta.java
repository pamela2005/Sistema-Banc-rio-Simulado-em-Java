package br.com.banco.model;

public abstract class Conta {
    private static int proximoNumero = 1;

    private int numero;
    protected double saldo;
    private Cliente titular;

    public Conta(Cliente titular) {
        this.numero = proximoNumero++;
        this.titular = titular;
        this.saldo = 0.0;
    }

    public int getNumero() {
        return numero;
    }

    public double getSaldo() {
        return saldo;
    }

    public Cliente getTitular() {
        return titular;
    }

    public void depositar(double valor) {
        if (valor > 0) saldo += valor;
    }

    public boolean sacar(double valor) {
        if (valor > 0 && saldo >= valor) {
            saldo -= valor;
            return true;
        }
        return false;
    }

    public boolean transferir(Conta destino, double valor) {
        if (this.sacar(valor)) {
            destino.depositar(valor);
            return true;
        }
        return false;
    }

    public abstract void atualizarMensal();

    @Override
    public String toString() {
        return "Conta Nº: " + numero + " | Titular: " + titular.getNome() + " | Saldo: R$" + saldo;
    }
}