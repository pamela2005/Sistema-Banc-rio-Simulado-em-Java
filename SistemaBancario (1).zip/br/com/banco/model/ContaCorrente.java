package br.com.banco.model;

public class ContaCorrente extends Conta {
    public ContaCorrente(Cliente titular) {
        super(titular);
    }

    @Override
    public void atualizarMensal() {
        sacar(12.00); // tarifa mensal
    }
}