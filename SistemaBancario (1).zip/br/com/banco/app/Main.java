package br.com.banco.app;

import br.com.banco.model.*;
import br.com.banco.service.BancoService;

import java.util.Scanner;

public class Main {
    public static void main(String[] args) {
        BancoService banco = new BancoService();
        Scanner sc = new Scanner(System.in);

        while (true) {
            System.out.println("\n=== MENU BANCO ===");
            System.out.println("1 - Criar Conta");
            System.out.println("2 - Depositar");
            System.out.println("3 - Sacar");
            System.out.println("4 - Transferir");
            System.out.println("5 - Atualizar Contas");
            System.out.println("6 - Listar Contas");
            System.out.println("0 - Sair");
            System.out.print("Escolha: ");
            int op = sc.nextInt();

            switch (op) {
                case 1:
                    sc.nextLine(); // limpar buffer
                    System.out.print("Nome do cliente: ");
                    String nome = sc.nextLine();
                    System.out.print("CPF: ");
                    String cpf = sc.nextLine();

                    Cliente cliente = new Cliente(nome, cpf);

                    System.out.print("Tipo (1-Corrente, 2-Poupança): ");
                    int tipo = sc.nextInt();

                    Conta conta = (tipo == 1) ? new ContaCorrente(cliente) : new ContaPoupanca(cliente);
                    banco.adicionarConta(conta);
                    System.out.println("Conta criada com sucesso! Nº " + conta.getNumero());
                    break;

                case 2:
                    System.out.print("Número da conta: ");
                    int numDep = sc.nextInt();
                    System.out.print("Valor: ");
                    double valDep = sc.nextDouble();
                    Conta cDep = banco.buscarConta(numDep);
                    if (cDep != null) {
                        cDep.depositar(valDep);
                        System.out.println("Depósito feito!");
                    } else {
                        System.out.println("Conta não encontrada.");
                    }
                    break;

                case 3:
                    System.out.print("Número da conta: ");
                    int numSaq = sc.nextInt();
                    System.out.print("Valor: ");
                    double valSaq = sc.nextDouble();
                    Conta cSaq = banco.buscarConta(numSaq);
                    if (cSaq != null && cSaq.sacar(valSaq)) {
                        System.out.println("Saque realizado.");
                    } else {
                        System.out.println("Erro: saldo insuficiente ou conta não encontrada.");
                    }
                    break;

                case 4:
                    System.out.print("Conta origem: ");
                    int origem = sc.nextInt();
                    System.out.print("Conta destino: ");
                    int destino = sc.nextInt();
                    System.out.print("Valor: ");
                    double valTrans = sc.nextDouble();
                    Conta cOrig = banco.buscarConta(origem);
                    Conta cDest = banco.buscarConta(destino);

                    if (cOrig != null && cDest != null && cOrig.transferir(cDest, valTrans)) {
                        System.out.println("Transferência realizada.");
                    } else {
                        System.out.println("Erro na transferência.");
                    }
                    break;

                case 5:
                    banco.aplicarAtualizacaoMensal();
                    System.out.println("Atualização mensal aplicada.");
                    break;

                case 6:
                    banco.listarContas();
                    break;

                case 0:
                    System.out.println("Encerrando o sistema...");
                    System.exit(0);

                default:
                    System.out.println("Opção inválida.");
            }
        }
    }
}